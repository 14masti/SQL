package com.masti.health.HealthManagment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HealthManagmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(HealthManagmentApplication.class, args);
	}

}
